# API Documentation

Smart Campus does not run a hand-written Express/REST server. The backend is **Supabase**, which
auto-generates a REST API (PostgREST) and a realtime API directly from the Postgres schema in
`supabase/migrations/`. The frontend calls this API through `@supabase/supabase-js`
(`src/integrations/supabase/client.ts`), never with raw `fetch`.

A machine-readable OpenAPI description is in [`docs/openapi.yaml`](./openapi.yaml) — every table
below maps 1:1 to a `/rest/v1/{table}` endpoint documented there. This file explains how to read it
and which of the app's own functions call each endpoint.

## Base URL & auth

```
Base URL : {SUPABASE_URL}/rest/v1
Auth     : Authorization: Bearer <user JWT>   (added automatically by supabase-js after sign-in)
API key  : apikey: <publishable key>          (from VITE_SUPABASE_PUBLISHABLE_KEY)
```

Every endpoint requires a valid session except `GET /events` and `GET /departments`, which also allow
the `anon` key (used by the public landing page).

## Endpoints

Each table gets the standard PostgREST verbs. `Allowed by` refers to the Postgres RLS policy that
gates the operation — see `supabase/migrations/20260810072056_*.sql` for exact SQL.

| Table | GET | POST | PATCH | DELETE | Allowed by |
| --- | --- | --- | --- | --- | --- |
| `departments` | ✅ all | admin | admin | admin | `has_role(admin)` |
| `profiles` | ✅ self + staff | — (via auth trigger) | self (own row) / admin (any row) | admin | `id = auth.uid()` or `is_staff()` / `has_role(admin)` |
| `user_roles` | ✅ self + staff | admin | — | admin | `has_role(admin)` for writes |
| `courses` | ✅ all | coordinator/admin | coordinator/admin | coordinator/admin | `can_manage_campus()` |
| `clubs` | ✅ all | coordinator/admin | coordinator/admin | coordinator/admin | `can_manage_campus()` |
| `club_members` | ✅ all | self | — | self | `user_id = auth.uid()` |
| `attendance_sessions` | ✅ all | faculty/coordinator/admin | same | same | `is_staff()` |
| `attendance_records` | ✅ self + staff | staff | staff | staff | `student_id = auth.uid()` or `is_staff()` |
| `assignments` | ✅ all | staff | staff | staff | `is_staff()` |
| `assignment_submissions` | ✅ self + staff | self | self (own) / staff (grading) | — | `student_id = auth.uid()` / `is_staff()` |
| `events` | ✅ all (public) | coordinator/admin | coordinator/admin | coordinator/admin | `can_manage_campus()` |
| `event_registrations` | ✅ self + staff | self | — | self / coordinator/admin | `student_id = auth.uid()` |
| `placements` | ✅ all | coordinator/admin | coordinator/admin | coordinator/admin | `can_manage_campus()` |
| `placement_applications` | ✅ self + staff | self | staff (status) | self | `student_id = auth.uid()` / `is_staff()` |
| `announcements` | ✅ all | staff | staff | staff | `is_staff()` |
| `notifications` | ✅ self | staff (for any user) | self | self | `user_id = auth.uid()` |
| `activity_logs` | ✅ admin only | — (trigger-based) | — | — | `has_role(admin)` |
| `user_settings` | ✅ self | self | self | self | `user_id = auth.uid()` |

`staff` = faculty, coordinator, or admin. `coordinator/admin` = coordinator or admin only. `admin` = admin only.

## App-level functions that call these endpoints

All calls are centralized in [`src/lib/campus.ts`](../src/lib/campus.ts) so every screen shares the
same query/mutation shape with TanStack Query:

- `fetchDepartments`, `fetchCourses`, `fetchClubs`, `fetchEvents`, `fetchPlacements`,
  `fetchAssignments`, `fetchAttendanceSessions`, `fetchAttendanceRecords`, `fetchAnnouncements`,
  `fetchNotifications`, `fetchClubMemberships`, `fetchMyRegistrations`, `fetchMyApplications`,
  `fetchSubmissions` — read endpoints (`GET`).
- `createAnnouncement(input)` — `POST /announcements` (staff only). Used by the **Admin → Post
  announcement** tab.
- `fetchAllProfiles()` — joins `GET /profiles` with `GET /user_roles` client-side for the admin
  Users list.
- `updateStudentPerformance(userId, { cgpa, semester, is_approved })` — `PATCH /profiles?id=eq.{userId}`.
  This is the "update student performance" action in the admin panel.
- `setUserRole(userId, role, grant)` — `POST` (upsert) or `DELETE` on `/user_roles`, used to promote
  or demote a user between student/faculty/coordinator/admin.
- `revokeUserAccess(userId)` — clears a user's roles and flips `profiles.is_approved` to `false`.

## Auth endpoints (Supabase Auth, not PostgREST)

| Action | Call |
| --- | --- |
| Sign up (email) | `supabase.auth.signUp({ email, password })` |
| Sign in (email) | `supabase.auth.signInWithPassword({ email, password })` |
| Sign in (Google) | `supabase.auth.signInWithOAuth({ provider: "google" })` |
| Request password reset | `supabase.auth.resetPasswordForEmail(email, { redirectTo })` |
| Set new password | `supabase.auth.updateUser({ password })` (on `/reset-password`) |
| Sign out | `supabase.auth.signOut()` |
| Get current session | `supabase.auth.getSession()` / `onAuthStateChange` |

## Trying it with curl

```sh
# Sign in to get a JWT
curl -X POST "$SUPABASE_URL/auth/v1/token?grant_type=password" \
  -H "apikey: $SUPABASE_PUBLISHABLE_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@smartcampus.test","password":"Campus@1234"}'

# Use the access_token from the response above
curl "$SUPABASE_URL/rest/v1/profiles?select=*" \
  -H "apikey: $SUPABASE_PUBLISHABLE_KEY" \
  -H "Authorization: Bearer <access_token>"
```

See [`docs/openapi.yaml`](./openapi.yaml) for the formal OpenAPI 3.0 spec (importable into Swagger UI
or Postman).
