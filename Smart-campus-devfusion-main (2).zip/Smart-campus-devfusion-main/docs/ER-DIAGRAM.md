# Entity–Relationship Diagram

Generated from `supabase/migrations/20260810072056_*.sql` (the single source of truth for the schema).
Render this file on GitHub, or paste the block into [mermaid.live](https://mermaid.live) for an image/SVG export.

```mermaid
erDiagram
    DEPARTMENTS ||--o{ PROFILES : "has students/staff"
    DEPARTMENTS ||--o{ COURSES : offers

    PROFILES ||--o{ USER_ROLES : "assigned"
    PROFILES ||--o{ USER_SETTINGS : "has"
    PROFILES ||--o{ CLUB_MEMBERS : "joins"
    PROFILES ||--o{ ATTENDANCE_RECORDS : "marked in"
    PROFILES ||--o{ ASSIGNMENT_SUBMISSIONS : submits
    PROFILES ||--o{ EVENT_REGISTRATIONS : registers
    PROFILES ||--o{ PLACEMENT_APPLICATIONS : applies
    PROFILES ||--o{ NOTIFICATIONS : receives
    PROFILES ||--o{ ANNOUNCEMENTS : authors
    PROFILES ||--o{ ACTIVITY_LOGS : "acts (audit)"
    PROFILES ||--o{ COURSES : "teaches (faculty_id)"
    PROFILES ||--o{ ATTENDANCE_SESSIONS : "runs (faculty_id)"
    PROFILES ||--o{ ASSIGNMENTS : "creates (faculty_id)"
    PROFILES ||--o{ CLUBS : "leads (lead_id)"
    PROFILES ||--o{ EVENTS : "creates (created_by)"
    PROFILES ||--o{ PLACEMENTS : "creates (created_by)"

    COURSES ||--o{ ATTENDANCE_SESSIONS : has
    COURSES ||--o{ ASSIGNMENTS : has

    CLUBS ||--o{ CLUB_MEMBERS : has

    ATTENDANCE_SESSIONS ||--o{ ATTENDANCE_RECORDS : has

    ASSIGNMENTS ||--o{ ASSIGNMENT_SUBMISSIONS : has

    EVENTS ||--o{ EVENT_REGISTRATIONS : has

    PLACEMENTS ||--o{ PLACEMENT_APPLICATIONS : has

    DEPARTMENTS {
        uuid id PK
        text name
        text code
    }

    PROFILES {
        uuid id PK "FK -> auth.users"
        text full_name
        text email
        text roll_number
        uuid department_id FK
        int semester
        numeric cgpa "student performance"
        text[] skills
        text linkedin_url
        text github_url
        text resume_url
        boolean is_approved
    }

    USER_ROLES {
        uuid id PK
        uuid user_id FK
        enum role "student | faculty | coordinator | admin"
    }

    USER_SETTINGS {
        uuid user_id PK "FK -> auth.users"
        text theme
        boolean email_notifications
        boolean push_notifications
        text profile_visibility
    }

    COURSES {
        uuid id PK
        text code
        text title
        uuid department_id FK
        int semester
        int credits
        uuid faculty_id FK
    }

    CLUBS {
        uuid id PK
        text name
        text category
        uuid lead_id FK
    }

    CLUB_MEMBERS {
        uuid id PK
        uuid club_id FK
        uuid user_id FK
    }

    ATTENDANCE_SESSIONS {
        uuid id PK
        uuid course_id FK
        uuid faculty_id FK
        date session_date
        text topic
    }

    ATTENDANCE_RECORDS {
        uuid id PK
        uuid session_id FK
        uuid student_id FK
        enum status "present | absent | late"
    }

    ASSIGNMENTS {
        uuid id PK
        uuid course_id FK
        uuid faculty_id FK
        text title
        int max_marks
        timestamptz deadline
    }

    ASSIGNMENT_SUBMISSIONS {
        uuid id PK
        uuid assignment_id FK
        uuid student_id FK
        text file_url
        text github_url
        boolean is_late
        int marks
        text feedback
    }

    EVENTS {
        uuid id PK
        text title
        text venue
        text[] speakers
        int seats
        timestamptz starts_at
        timestamptz registration_deadline
        uuid created_by FK
    }

    EVENT_REGISTRATIONS {
        uuid id PK
        uuid event_id FK
        uuid student_id FK
        text ticket_code "QR-pass code"
    }

    PLACEMENTS {
        uuid id PK
        text company
        text role_title
        text ctc
        numeric min_cgpa
        timestamptz deadline
        uuid created_by FK
    }

    PLACEMENT_APPLICATIONS {
        uuid id PK
        uuid placement_id FK
        uuid student_id FK
        enum status "applied | shortlisted | rejected | selected"
    }

    ANNOUNCEMENTS {
        uuid id PK
        text title
        text body
        boolean is_pinned
        uuid author_id FK
    }

    NOTIFICATIONS {
        uuid id PK
        uuid user_id FK
        text title
        text category
        boolean is_read
    }

    ACTIVITY_LOGS {
        uuid id PK
        uuid actor_id FK
        text action
        text entity
        jsonb details
    }
```

## Notes

- Every table has Row Level Security (RLS) enabled; relationships shown above are enforced both by
  foreign keys and by RLS policies (see the migration file for the exact `USING` / `WITH CHECK` clauses).
- `profiles.id` is a 1:1 extension of Supabase's built-in `auth.users` table — there is no separate
  `users` table because Supabase Auth owns credentials, and `profiles` owns campus-specific data.
- `profiles.cgpa`, `profiles.semester` and `profiles.is_approved` are the fields the **admin panel's
  "Users & performance" tab** writes to when an administrator updates a student's performance record.
