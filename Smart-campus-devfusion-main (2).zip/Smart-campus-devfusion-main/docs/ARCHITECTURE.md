# Architecture Diagram

```mermaid
flowchart TB
    subgraph Client["Browser"]
        UI["React 19 UI\nTanStack Router + Query\nTailwind CSS v4 / shadcn-ui"]
    end

    subgraph Edge["TanStack Start Server (Vite/Nitro)"]
        SSR["Server-side rendering\n& route loaders"]
        MW["Auth middleware\n(src/integrations/supabase/auth-middleware.ts)"]
    end

    subgraph Supabase["Supabase Platform"]
        AUTH["Supabase Auth\nEmail+Password / Google OAuth\nJWT sessions"]
        PG[("PostgreSQL\n18 tables, Row Level Security")]
        RPC["Postgres functions\nhas_role / is_staff / can_manage_campus"]
        STORAGE["Storage buckets\n(avatars, resumes, banners - links)"]
    end

    UI -->|"HTTPS / fetch"| SSR
    SSR --> MW
    MW -->|"verifies JWT"| AUTH
    UI -->|"supabase-js client\n(anon key, RLS enforced)"| PG
    PG --> RPC
    UI -.->|"file links"| STORAGE
    AUTH -->|"issues session"| UI

    classDef ext fill:#eef,stroke:#88f;
    class Supabase ext;
```

## Component overview

| Layer | Technology | Responsibility |
| --- | --- | --- |
| UI | React 19, TanStack Router, TanStack Query, Tailwind v4, shadcn/ui | Renders role-aware dashboards, forms, and the public landing page |
| App server | TanStack Start (Vite + Nitro) | Route-level SSR, redirects unauthenticated users, serves the built app |
| Auth | Supabase Auth | Email/password + Google OAuth, JWT/session cookies, password reset |
| Data | Supabase Postgres | 18 tables (see `docs/ER-DIAGRAM.md`), every table has RLS policies |
| Authorization | Postgres `SECURITY DEFINER` functions | `has_role`, `is_staff`, `can_manage_campus` decide what a JWT's user may read/write, enforced at the database layer (not just in the UI) |
| Client access | `@supabase/supabase-js` (PostgREST under the hood) | The browser talks to Postgres directly through Supabase's auto-generated REST API — see `docs/API.md` |

## Request flow (example: admin updates a student's CGPA)

1. Admin signs in → Supabase Auth issues a JWT embedding the user's `id`.
2. Admin panel calls `supabase.from("profiles").update({ cgpa, semester, is_approved }).eq("id", studentId)`.
3. PostgREST (inside Supabase) receives the request with the JWT attached.
4. Postgres RLS policy `profiles admin write` evaluates `has_role(auth.uid(), 'admin')` — only passes if the caller holds the `admin` role in `user_roles`.
5. Row is updated; TanStack Query invalidates the `admin-profiles` cache and the UI re-renders.

This means authorization is enforced twice: once by the UI (hiding the Admin panel from non-admins) and once by the database (rejecting the write even if someone calls the API directly).
