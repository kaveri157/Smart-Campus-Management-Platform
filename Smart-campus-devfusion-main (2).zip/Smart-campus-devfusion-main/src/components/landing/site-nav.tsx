import { Link } from "@tanstack/react-router";
import { GraduationCap, Menu, Moon, Sun, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/lib/theme";

const sections = [
  { href: "#features", label: "Modules" },
  { href: "#numbers", label: "Numbers" },
  { href: "#voices", label: "Voices" },
];

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const { session } = useAuth();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-6 px-5">
        <Link to="/" className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-md bg-primary/15 text-primary">
            <GraduationCap className="size-5" />
          </span>
          <span className="font-display text-base font-semibold">Smart Campus</span>
        </Link>

        <nav className="ml-auto hidden items-center gap-7 md:flex">
          {sections.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <Button variant="ghost" size="icon" onClick={toggle} aria-label="Switch colour theme">
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
          {session ? (
            <Button asChild size="sm" className="hidden md:inline-flex">
              <Link to="/dashboard">Open dashboard</Link>
            </Button>
          ) : (
            <Button asChild size="sm" className="hidden md:inline-flex">
              <Link to="/auth">Sign in</Link>
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle navigation"
          >
            {open ? <X className="size-4" /> : <Menu className="size-4" />}
          </Button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border/60 bg-background px-5 py-4 md:hidden">
          <nav className="flex flex-col gap-3">
            {sections.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="text-sm text-muted-foreground"
              >
                {item.label}
              </a>
            ))}
            <Button asChild size="sm" className="mt-2">
              <Link to={session ? "/dashboard" : "/auth"}>
                {session ? "Open dashboard" : "Sign in"}
              </Link>
            </Button>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
