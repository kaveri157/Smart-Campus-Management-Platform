import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  BriefcaseBusiness,
  CalendarCheck,
  ClipboardList,
  FileCheck2,
  Megaphone,
  ShieldCheck,
  UsersRound,
  BellRing,
} from "lucide-react";

import heroImage from "@/assets/campus-hero.jpg";

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border/60">
      <div className="pointer-events-none absolute inset-0 grid-veil opacity-70" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] glow-halo" />
      <div className="relative mx-auto grid w-full max-w-6xl gap-12 px-5 py-20 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:py-28">
        <div>
          <Badge variant="secondary" className="rounded-full px-3 py-1 text-xs font-medium">
            Built for DevFusion 4.0 · Problem Statement 1
          </Badge>
          <h1 className="mt-6 text-4xl leading-[1.05] font-semibold sm:text-5xl lg:text-6xl">
            Your college runs on twelve WhatsApp groups. It shouldn't.
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">
            Smart Campus puts attendance, assignments, events, placement drives and notices behind
            one sign-in, with a dashboard shaped for whichever role you hold — student, faculty,
            coordinator or administrator.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button asChild size="lg">
              <Link to="/auth">Enter the portal</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <a href="#features">See what's inside</a>
            </Button>
          </div>
          <dl className="mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-border/60 pt-8">
            {[
              { value: "4", label: "Permission tiers" },
              { value: "17", label: "Linked tables" },
              { value: "9", label: "Campus modules" },
            ].map((item) => (
              <div key={item.label}>
                <dt className="font-display text-2xl font-semibold text-foreground">
                  {item.value}
                </dt>
                <dd className="mt-1 text-xs text-muted-foreground">{item.label}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-xl border border-border/70 shadow-lift">
            <img
              src={heroImage}
              alt="Wireframe rendering of a campus with floating attendance and calendar panels"
              width={1600}
              height={1008}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

const modules = [
  {
    icon: ClipboardList,
    title: "Attendance that adds up",
    body: "Faculty open a session per lecture and mark it in one pass. Students see percentage, subject split and a monthly trend.",
  },
  {
    icon: FileCheck2,
    title: "Assignments end to end",
    body: "Deadlines, rubrics and attachments on one side; PDF, archive or GitHub submissions with late flags and grading on the other.",
  },
  {
    icon: CalendarCheck,
    title: "Events with real tickets",
    body: "Seat limits, registration cut-offs and a scannable pass code issued the moment a student registers.",
  },
  {
    icon: BriefcaseBusiness,
    title: "Placement drives",
    body: "Company, role, CTC, eligibility and deadline in one card, with application status tracked from applied to selected.",
  },
  {
    icon: Megaphone,
    title: "Notices, not noise",
    body: "Announcements targeted at students, faculty or the whole campus, pinned when they matter.",
  },
  {
    icon: BellRing,
    title: "Notifications",
    body: "Attendance marked, assignment due, drive opened — each lands in the bell with an unread count.",
  },
  {
    icon: UsersRound,
    title: "Clubs and societies",
    body: "Join or leave a club in a click; coordinators keep the roster and the calendar in the same place.",
  },
  {
    icon: ShieldCheck,
    title: "Permissions you can defend",
    body: "Roles live in their own table and every read and write is checked in the database, not just hidden in the interface.",
  },
];

export function Modules() {
  return (
    <section id="features" className="border-b border-border/60 py-20">
      <div className="mx-auto w-full max-w-6xl px-5">
        <p className="font-display text-xs tracking-[0.28em] text-primary">MODULES</p>
        <h2 className="mt-4 max-w-2xl text-3xl font-semibold sm:text-4xl">
          Nine things a college does every week, in one place
        </h2>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {modules.map((item) => (
            <Card key={item.title} className="border-border/70 bg-card/60">
              <CardContent className="p-6">
                <span className="grid size-10 place-items-center rounded-md bg-primary/12 text-primary">
                  <item.icon className="size-5" />
                </span>
                <h3 className="mt-5 text-base font-semibold">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Numbers() {
  const rows = [
    { value: "6", label: "Departments and course tracks seeded" },
    { value: "100%", label: "Tables protected by row-level rules" },
    { value: "<1s", label: "Dashboard queries on seeded data" },
    { value: "2", label: "Sign-in methods, email and Google" },
  ];
  return (
    <section id="numbers" className="border-b border-border/60 bg-secondary/40 py-16">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-5 sm:grid-cols-2 lg:grid-cols-4">
        {rows.map((row) => (
          <div key={row.label}>
            <p className="font-display text-4xl font-semibold text-primary">{row.value}</p>
            <p className="mt-2 text-sm text-muted-foreground">{row.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

const voices = [
  {
    quote:
      "I used to keep attendance in a spreadsheet and mail it around at the end of the month. Now the session closes and the percentage is already there.",
    name: "Prof. Meera Joshi",
    role: "Faculty, Computer Engineering",
  },
  {
    quote:
      "Submitting a GitHub link instead of zipping a folder and mailing it saved me the usual deadline panic.",
    name: "Rohit Kadam",
    role: "Final year, Information Technology",
  },
  {
    quote:
      "Event seats, club rosters and approvals stopped living in my DMs. That alone was worth the switch.",
    name: "Sneha Pawar",
    role: "Cultural Coordinator",
  },
];

export function Voices() {
  return (
    <section id="voices" className="border-b border-border/60 py-20">
      <div className="mx-auto w-full max-w-6xl px-5">
        <p className="font-display text-xs tracking-[0.28em] text-primary">VOICES</p>
        <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">What the pilot users said</h2>
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {voices.map((voice) => (
            <Card key={voice.name} className="border-border/70">
              <CardContent className="p-6">
                <p className="text-sm leading-relaxed">&ldquo;{voice.quote}&rdquo;</p>
                <div className="mt-6 border-t border-border/60 pt-4">
                  <p className="text-sm font-semibold">{voice.name}</p>
                  <p className="text-xs text-muted-foreground">{voice.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

export function SiteFooter() {
  return (
    <footer className="py-12">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-sm font-semibold">Smart Campus</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Built by Somesh Ambre and Kaveri Dhatrak for DevFusion 4.0.
          </p>
        </div>
        <div className="flex items-center gap-5 text-xs text-muted-foreground">
          <a href="#features" className="hover:text-foreground">
            Modules
          </a>
          <Link to="/auth" className="hover:text-foreground">
            Sign in
          </Link>
        </div>
      </div>
    </footer>
  );
}
