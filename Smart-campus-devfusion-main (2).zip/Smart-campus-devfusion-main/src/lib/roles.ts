export const ROLES = ["student", "faculty", "coordinator", "admin"] as const;

export type Role = (typeof ROLES)[number];

export const ROLE_LABEL: Record<Role, string> = {
  student: "Student",
  faculty: "Faculty",
  coordinator: "Coordinator",
  admin: "Administrator",
};

export function primaryRole(roles: Role[]): Role {
  if (roles.includes("admin")) return "admin";
  if (roles.includes("coordinator")) return "coordinator";
  if (roles.includes("faculty")) return "faculty";
  return "student";
}

export function isStaff(roles: Role[]) {
  return roles.some((r) => r !== "student");
}

export function canManageCampus(roles: Role[]) {
  return roles.includes("admin") || roles.includes("coordinator");
}
