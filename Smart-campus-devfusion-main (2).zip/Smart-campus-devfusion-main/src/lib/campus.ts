import { supabase } from "@/integrations/supabase/client";
import type { Role } from "@/lib/roles";

export type CourseRow = {
  id: string;
  code: string;
  title: string;
  semester: number;
  credits: number;
  department_id: string | null;
};

export async function fetchCourses() {
  const { data, error } = await supabase.from("courses").select("*").order("code");
  if (error) throw error;
  return (data ?? []) as CourseRow[];
}

export async function fetchDepartments() {
  const { data, error } = await supabase.from("departments").select("*").order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchEvents() {
  const { data, error } = await supabase.from("events").select("*").order("starts_at");
  if (error) throw error;
  return data ?? [];
}

export async function fetchMyRegistrations() {
  const { data, error } = await supabase.from("event_registrations").select("*");
  if (error) throw error;
  return data ?? [];
}

export async function fetchPlacements() {
  const { data, error } = await supabase.from("placements").select("*").order("deadline");
  if (error) throw error;
  return data ?? [];
}

export async function fetchMyApplications() {
  const { data, error } = await supabase.from("placement_applications").select("*");
  if (error) throw error;
  return data ?? [];
}

export async function fetchAssignments() {
  const { data, error } = await supabase
    .from("assignments")
    .select("*, courses(code, title)")
    .order("deadline");
  if (error) throw error;
  return data ?? [];
}

export async function fetchSubmissions() {
  const { data, error } = await supabase
    .from("assignment_submissions")
    .select("*, profiles:student_id(full_name, roll_number)")
    .order("submitted_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchAttendanceSessions() {
  const { data, error } = await supabase
    .from("attendance_sessions")
    .select("*, courses(code, title)")
    .order("session_date", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchAttendanceRecords() {
  const { data, error } = await supabase
    .from("attendance_records")
    .select("*, attendance_sessions(session_date, course_id, courses(code, title))");
  if (error) throw error;
  return data ?? [];
}

export async function fetchClubs() {
  const { data, error } = await supabase.from("clubs").select("*").order("name");
  if (error) throw error;
  return data ?? [];
}

export async function fetchClubMemberships() {
  const { data, error } = await supabase.from("club_members").select("*");
  if (error) throw error;
  return data ?? [];
}

export async function fetchAnnouncements() {
  const { data, error } = await supabase
    .from("announcements")
    .select("*")
    .order("is_pinned", { ascending: false })
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function createAnnouncement(input: {
  title: string;
  body: string;
  is_pinned: boolean;
  authorId: string;
}) {
  const { error } = await supabase.from("announcements").insert({
    title: input.title,
    body: input.body,
    is_pinned: input.is_pinned,
    author_id: input.authorId,
  });
  if (error) throw error;
}

export type AdminUserRow = {
  id: string;
  full_name: string;
  email: string;
  roll_number: string | null;
  semester: number | null;
  cgpa: number | null;
  is_approved: boolean;
  department_id: string | null;
  roles: Role[];
};

export async function fetchAllProfiles(): Promise<AdminUserRow[]> {
  const [profilesResult, rolesResult] = await Promise.all([
    supabase.from("profiles").select("*").order("full_name"),
    supabase.from("user_roles").select("user_id, role"),
  ]);
  if (profilesResult.error) throw profilesResult.error;
  if (rolesResult.error) throw rolesResult.error;

  const rolesByUser = new Map<string, Role[]>();
  for (const row of rolesResult.data ?? []) {
    const list = rolesByUser.get(row.user_id) ?? [];
    list.push(row.role as Role);
    rolesByUser.set(row.user_id, list);
  }

  return (profilesResult.data ?? []).map((p) => ({
    id: p.id,
    full_name: p.full_name,
    email: p.email,
    roll_number: p.roll_number,
    semester: p.semester,
    cgpa: p.cgpa,
    is_approved: p.is_approved,
    department_id: p.department_id,
    roles: rolesByUser.get(p.id) ?? [],
  }));
}

export async function updateStudentPerformance(
  userId: string,
  input: { cgpa: number | null; semester: number | null; is_approved: boolean },
) {
  const { error } = await supabase
    .from("profiles")
    .update({ cgpa: input.cgpa, semester: input.semester, is_approved: input.is_approved })
    .eq("id", userId);
  if (error) throw error;
}

export async function setUserRole(userId: string, role: Role, grant: boolean) {
  if (grant) {
    const { error } = await supabase
      .from("user_roles")
      .upsert({ user_id: userId, role }, { onConflict: "user_id,role" });
    if (error) throw error;
  } else {
    const { error } = await supabase
      .from("user_roles")
      .delete()
      .eq("user_id", userId)
      .eq("role", role);
    if (error) throw error;
  }
}

export async function revokeUserAccess(userId: string) {
  const { error: rolesError } = await supabase.from("user_roles").delete().eq("user_id", userId);
  if (rolesError) throw rolesError;
  const { error: profileError } = await supabase
    .from("profiles")
    .update({ is_approved: false })
    .eq("id", userId);
  if (profileError) throw profileError;
}

// ---- Assignments ----

export async function createAssignment(input: {
  course_id: string;
  faculty_id: string;
  title: string;
  description: string;
  max_marks: number;
  deadline: string;
  attachment_url?: string | null;
}) {
  const { error } = await supabase.from("assignments").insert(input);
  if (error) throw error;
}

export async function submitAssignment(input: {
  assignment_id: string;
  student_id: string;
  file_url?: string | null;
  github_url?: string | null;
  notes?: string | null;
  is_late: boolean;
}) {
  const { error } = await supabase.from("assignment_submissions").upsert(input, {
    onConflict: "assignment_id,student_id",
  });
  if (error) throw error;
}

export async function gradeSubmission(submissionId: string, marks: number, feedback: string) {
  const { error } = await supabase
    .from("assignment_submissions")
    .update({ marks, feedback, reviewed_at: new Date().toISOString() })
    .eq("id", submissionId);
  if (error) throw error;
}

// ---- Events ----

export async function createEvent(input: {
  title: string;
  description: string;
  venue: string;
  seats: number;
  starts_at: string;
  registration_deadline: string;
  created_by: string;
  speakers?: string[];
}) {
  const { error } = await supabase.from("events").insert(input);
  if (error) throw error;
}

export async function registerForEvent(eventId: string, studentId: string) {
  const { error } = await supabase
    .from("event_registrations")
    .insert({ event_id: eventId, student_id: studentId });
  if (error) throw error;
}

export async function cancelEventRegistration(eventId: string, studentId: string) {
  const { error } = await supabase
    .from("event_registrations")
    .delete()
    .eq("event_id", eventId)
    .eq("student_id", studentId);
  if (error) throw error;
}

// ---- Placements ----

export async function createPlacement(input: {
  company: string;
  role_title: string;
  description: string;
  ctc: string;
  eligibility: string;
  min_cgpa: number | null;
  deadline: string;
  created_by: string;
}) {
  const { error } = await supabase.from("placements").insert(input);
  if (error) throw error;
}

export async function applyToPlacement(
  placementId: string,
  studentId: string,
  resumeUrl: string | null,
) {
  const { error } = await supabase
    .from("placement_applications")
    .insert({ placement_id: placementId, student_id: studentId, resume_url: resumeUrl });
  if (error) throw error;
}

export async function withdrawApplication(placementId: string, studentId: string) {
  const { error } = await supabase
    .from("placement_applications")
    .delete()
    .eq("placement_id", placementId)
    .eq("student_id", studentId);
  if (error) throw error;
}

// ---- Clubs ----

export async function createClub(input: {
  name: string;
  description: string;
  category: string;
  lead_id: string;
}) {
  const { error } = await supabase.from("clubs").insert(input);
  if (error) throw error;
}

export async function joinClub(clubId: string, userId: string) {
  const { error } = await supabase
    .from("club_members")
    .insert({ club_id: clubId, user_id: userId });
  if (error) throw error;
}

export async function leaveClub(clubId: string, userId: string) {
  const { error } = await supabase
    .from("club_members")
    .delete()
    .eq("club_id", clubId)
    .eq("user_id", userId);
  if (error) throw error;
}

// ---- Notifications ----

export async function markNotificationRead(id: string, isRead = true) {
  const { error } = await supabase.from("notifications").update({ is_read: isRead }).eq("id", id);
  if (error) throw error;
}

export async function markAllNotificationsRead(userId: string) {
  const { error } = await supabase
    .from("notifications")
    .update({ is_read: true })
    .eq("user_id", userId)
    .eq("is_read", false);
  if (error) throw error;
}

export async function deleteNotification(id: string) {
  const { error } = await supabase.from("notifications").delete().eq("id", id);
  if (error) throw error;
}

// ---- Profile & settings ----

export async function updateProfile(
  userId: string,
  input: Partial<{
    full_name: string;
    phone: string | null;
    roll_number: string | null;
    department_id: string | null;
    semester: number | null;
    skills: string[];
    linkedin_url: string | null;
    github_url: string | null;
    resume_url: string | null;
    bio: string | null;
    avatar_url: string | null;
  }>,
) {
  const { error } = await supabase.from("profiles").update(input).eq("id", userId);
  if (error) throw error;
}

export type UserSettingsRow = {
  user_id: string;
  theme: string;
  email_notifications: boolean;
  push_notifications: boolean;
  profile_visibility: string;
};

export async function fetchUserSettings(userId: string) {
  const { data, error } = await supabase
    .from("user_settings")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw error;
  return data as UserSettingsRow | null;
}

export async function upsertUserSettings(input: UserSettingsRow) {
  const { error } = await supabase.from("user_settings").upsert(input, { onConflict: "user_id" });
  if (error) throw error;
}

export async function deleteOwnAccount(userId: string) {
  await supabase.from("user_roles").delete().eq("user_id", userId);
  const { error } = await supabase
    .from("profiles")
    .update({ is_approved: false, full_name: "Deleted user" })
    .eq("id", userId);
  if (error) throw error;
}

export async function fetchNotifications() {
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(60);
  if (error) throw error;
  return data ?? [];
}

export function attendancePercent(records: { status: string }[]) {
  if (records.length === 0) return 0;
  const attended = records.filter((r) => r.status !== "absent").length;
  return Math.round((attended / records.length) * 100);
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(value: string | null | undefined) {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function daysUntil(value: string) {
  const diff = new Date(value).getTime() - Date.now();
  return Math.ceil(diff / 86_400_000);
}
