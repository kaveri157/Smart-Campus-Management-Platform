import { createFileRoute } from "@tanstack/react-router";

import { Hero, Modules, Numbers, SiteFooter, Voices } from "@/components/landing/sections";
import { SiteNav } from "@/components/landing/site-nav";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Campus — attendance, assignments, events and placements in one portal" },
      {
        name: "description",
        content:
          "A role-aware campus portal for students, faculty, coordinators and administrators: attendance, assignments, events with QR passes, placement drives, notices and analytics.",
      },
      {
        property: "og:title",
        content: "Smart Campus — attendance, assignments, events and placements in one portal",
      },
      {
        property: "og:description",
        content:
          "One sign-in for attendance, assignments, events, placement drives and campus notices, with a dashboard per role.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />
      <main>
        <Hero />
        <Modules />
        <Numbers />
        <Voices />
      </main>
      <SiteFooter />
    </div>
  );
}
