import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import {
  cancelEventRegistration,
  createEvent,
  daysUntil,
  fetchEvents,
  fetchMyRegistrations,
  formatDateTime,
  registerForEvent,
} from "@/lib/campus";
import { canManageCampus } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/events")({
  component: EventsPage,
});

function EventsPage() {
  const { roles, user } = useAuth();
  const manager = canManageCampus(roles);
  const queryClient = useQueryClient();

  const events = useQuery({ queryKey: ["events"], queryFn: fetchEvents });
  const registrations = useQuery({ queryKey: ["my-registrations"], queryFn: fetchMyRegistrations });

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [venue, setVenue] = useState("");
  const [seats, setSeats] = useState("100");
  const [startsAt, setStartsAt] = useState("");
  const [regDeadline, setRegDeadline] = useState("");

  const createMutation = useMutation({
    mutationFn: () => {
      if (!user) throw new Error("Not signed in");
      if (!title.trim() || !startsAt || !regDeadline)
        throw new Error("Title, start time and deadline are required.");
      return createEvent({
        title: title.trim(),
        description: description.trim(),
        venue: venue.trim(),
        seats: Number(seats) || 100,
        starts_at: new Date(startsAt).toISOString(),
        registration_deadline: new Date(regDeadline).toISOString(),
        created_by: user.id,
      });
    },
    onSuccess: () => {
      toast.success("Event created");
      setTitle("");
      setDescription("");
      setVenue("");
      setStartsAt("");
      setRegDeadline("");
      void queryClient.invalidateQueries({ queryKey: ["events"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const rows = (events.data ?? []) as Record<string, unknown>[];
  const myTickets = new Map(
    (registrations.data ?? []).map((r) => [
      (r as Record<string, unknown>)["event_id"] as string,
      r as Record<string, unknown>,
    ]),
  );

  return (
    <div>
      <PageHeader
        title="Events"
        description={
          manager
            ? "Create fests, workshops and seminars, and track registrations."
            : "Fests, workshops and seminars happening across campus."
        }
      />

      {manager ? (
        <Card className="mb-6 border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Create an event</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="e-title">Title</Label>
              <Input id="e-title" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="e-venue">Venue</Label>
              <Input id="e-venue" value={venue} onChange={(e) => setVenue(e.target.value)} />
            </div>
            <div className="space-y-2 lg:col-span-4">
              <Label htmlFor="e-desc">Description</Label>
              <Textarea
                id="e-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-seats">Seats</Label>
              <Input
                id="e-seats"
                type="number"
                value={seats}
                onChange={(e) => setSeats(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="e-start">Starts at</Label>
              <Input
                id="e-start"
                type="datetime-local"
                value={startsAt}
                onChange={(e) => setStartsAt(e.target.value)}
              />
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="e-deadline">Registration deadline</Label>
              <Input
                id="e-deadline"
                type="datetime-local"
                value={regDeadline}
                onChange={(e) => setRegDeadline(e.target.value)}
              />
            </div>
            <div className="sm:col-span-2 lg:col-span-4">
              <Button onClick={() => createMutation.mutate()} disabled={createMutation.isPending}>
                Create event
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {events.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="Events will appear here once published."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => (
            <EventCard
              key={row["id"] as string}
              row={row}
              userId={user?.id ?? ""}
              ticket={myTickets.get(row["id"] as string)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EventCard({
  row,
  userId,
  ticket,
}: {
  row: Record<string, unknown>;
  userId: string;
  ticket: Record<string, unknown> | undefined;
}) {
  const queryClient = useQueryClient();
  const eventId = row["id"] as string;
  const closed = daysUntil(row["registration_deadline"] as string) < 0;

  const registerMutation = useMutation({
    mutationFn: () => registerForEvent(eventId, userId),
    onSuccess: () => {
      toast.success("Registered! Your ticket is ready.");
      void queryClient.invalidateQueries({ queryKey: ["my-registrations"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const cancelMutation = useMutation({
    mutationFn: () => cancelEventRegistration(eventId, userId),
    onSuccess: () => {
      toast.success("Registration cancelled");
      void queryClient.invalidateQueries({ queryKey: ["my-registrations"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <Card className="border-border/70">
      <CardContent className="space-y-3 p-5">
        <div className="flex items-start justify-between gap-2">
          <p className="font-medium">{row["title"] as string}</p>
          <Badge variant={closed ? "destructive" : "secondary"}>{closed ? "Closed" : "Open"}</Badge>
        </div>
        <p className="text-xs text-muted-foreground">
          {(row["venue"] as string) || "TBA"} · {formatDateTime(row["starts_at"] as string)}
        </p>
        <p className="line-clamp-3 text-sm text-muted-foreground">
          {(row["description"] as string) ?? ""}
        </p>

        {ticket ? (
          <div className="space-y-2 rounded-md border border-border/60 p-3">
            <p className="text-xs font-medium">Ticket: {ticket["ticket_code"] as string}</p>
            <img
              alt="Event QR pass"
              className="h-28 w-28 rounded bg-white p-1"
              src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                ticket["ticket_code"] as string,
              )}`}
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() => cancelMutation.mutate()}
              disabled={cancelMutation.isPending}
            >
              Cancel registration
            </Button>
          </div>
        ) : (
          <Button
            size="sm"
            onClick={() => registerMutation.mutate()}
            disabled={closed || registerMutation.isPending}
          >
            Register
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
