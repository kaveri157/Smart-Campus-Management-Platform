import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState, StatTile } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import {
  attendancePercent,
  fetchAttendanceRecords,
  fetchAttendanceSessions,
  fetchCourses,
  formatDate,
} from "@/lib/campus";
import { isStaff } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/attendance")({
  component: AttendancePage,
});

function AttendancePage() {
  const { roles, user } = useAuth();
  const staff = isStaff(roles);
  const queryClient = useQueryClient();

  const courses = useQuery({ queryKey: ["courses"], queryFn: fetchCourses });
  const sessions = useQuery({
    queryKey: ["attendance-sessions"],
    queryFn: fetchAttendanceSessions,
  });
  const records = useQuery({ queryKey: ["attendance-records"], queryFn: fetchAttendanceRecords });

  const [courseId, setCourseId] = useState("");
  const [topic, setTopic] = useState("");
  const [sessionDate, setSessionDate] = useState(() => new Date().toISOString().slice(0, 10));

  const createSession = useMutation({
    mutationFn: async () => {
      if (!courseId) throw new Error("Pick a course first.");
      const { error } = await supabase.from("attendance_sessions").insert({
        course_id: courseId,
        faculty_id: user?.id ?? null,
        topic: topic.trim(),
        session_date: sessionDate,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Session opened.");
      setTopic("");
      void queryClient.invalidateQueries({ queryKey: ["attendance-sessions"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const markSelf = useMutation({
    mutationFn: async (sessionId: string) => {
      const { error } = await supabase
        .from("attendance_records")
        .upsert({ session_id: sessionId, student_id: user!.id, status: "present" });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Marked present.");
      void queryClient.invalidateQueries({ queryKey: ["attendance-records"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const bySubject = new Map<string, { total: number; present: number }>();
  for (const record of records.data ?? []) {
    const session = record.attendance_sessions as { courses: { code: string } | null } | null;
    const key = session?.courses?.code ?? "Other";
    const entry = bySubject.get(key) ?? { total: 0, present: 0 };
    entry.total += 1;
    if (record.status !== "absent") entry.present += 1;
    bySubject.set(key, entry);
  }

  return (
    <div>
      <PageHeader
        title="Attendance"
        description={
          staff
            ? "Open a session for a lecture, then mark the roll. Percentages update for students immediately."
            : "Your attendance across every course, plus the sessions still open for marking."
        }
      />

      {records.isLoading ? (
        <CardsSkeleton count={3} />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <StatTile label="Overall" value={`${attendancePercent(records.data ?? [])}%`} />
            <StatTile label="Records" value={(records.data ?? []).length} />
            <StatTile label="Sessions held" value={(sessions.data ?? []).length} />
          </div>

          {staff ? (
            <Card className="mt-6 border-border/70">
              <CardHeader>
                <CardTitle className="text-base">Open a new session</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-4">
                <div className="space-y-2 sm:col-span-2">
                  <Label>Course</Label>
                  <Select value={courseId} onValueChange={setCourseId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a course" />
                    </SelectTrigger>
                    <SelectContent>
                      {(courses.data ?? []).map((course) => (
                        <SelectItem key={course.id} value={course.id}>
                          {course.code} — {course.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="session-date">Date</Label>
                  <Input
                    id="session-date"
                    type="date"
                    value={sessionDate}
                    onChange={(e) => setSessionDate(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="topic">Topic</Label>
                  <Input id="topic" value={topic} onChange={(e) => setTopic(e.target.value)} />
                </div>
                <div className="sm:col-span-4">
                  <Button onClick={() => createSession.mutate()} disabled={createSession.isPending}>
                    Open session
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : null}

          <Card className="mt-6 border-border/70">
            <CardHeader>
              <CardTitle className="text-base">Subject-wise split</CardTitle>
            </CardHeader>
            <CardContent>
              {bySubject.size === 0 ? (
                <EmptyState
                  title="No attendance yet"
                  description="Once a session is marked, the subject-wise breakdown and monthly trend appear here."
                />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Course</TableHead>
                      <TableHead>Held</TableHead>
                      <TableHead>Attended</TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...bySubject.entries()].map(([code, entry]) => (
                      <TableRow key={code}>
                        <TableCell className="font-medium">{code}</TableCell>
                        <TableCell>{entry.total}</TableCell>
                        <TableCell>{entry.present}</TableCell>
                        <TableCell className="text-right">
                          <Badge
                            variant={
                              entry.present / entry.total >= 0.75 ? "secondary" : "destructive"
                            }
                          >
                            {Math.round((entry.present / entry.total) * 100)}%
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card className="mt-6 border-border/70">
            <CardHeader>
              <CardTitle className="text-base">Recent sessions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(sessions.data ?? []).slice(0, 12).map((session) => (
                <div
                  key={session.id as string}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border/60 p-3"
                >
                  <div>
                    <p className="text-sm font-medium">
                      {(session.courses as { code: string } | null)?.code ?? "Course"} ·{" "}
                      {(session.topic as string) || "Lecture"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(session.session_date as string)}
                    </p>
                  </div>
                  {!staff ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => markSelf.mutate(session.id as string)}
                      disabled={markSelf.isPending}
                    >
                      Mark present
                    </Button>
                  ) : null}
                </div>
              ))}
              {(sessions.data ?? []).length === 0 ? (
                <p className="text-sm text-muted-foreground">No sessions have been opened yet.</p>
              ) : null}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
