import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, StatTile } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import {
  attendancePercent,
  daysUntil,
  fetchAnnouncements,
  fetchAssignments,
  fetchAttendanceRecords,
  fetchEvents,
  fetchPlacements,
  formatDate,
} from "@/lib/campus";
import { ROLE_LABEL } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const { profile, role } = useAuth();

  const attendance = useQuery({
    queryKey: ["attendance-records"],
    queryFn: fetchAttendanceRecords,
  });
  const assignments = useQuery({ queryKey: ["assignments"], queryFn: fetchAssignments });
  const events = useQuery({ queryKey: ["events"], queryFn: fetchEvents });
  const placements = useQuery({ queryKey: ["placements"], queryFn: fetchPlacements });
  const announcements = useQuery({ queryKey: ["announcements"], queryFn: fetchAnnouncements });

  const loading = attendance.isLoading || assignments.isLoading || events.isLoading;
  const percent = attendancePercent(attendance.data ?? []);
  const openAssignments = (assignments.data ?? []).filter(
    (a) => daysUntil(a.deadline as string) >= 0,
  );
  const upcomingEvents = (events.data ?? []).filter((e) => daysUntil(e.starts_at as string) >= 0);
  const openDrives = (placements.data ?? []).filter((p) => daysUntil(p.deadline as string) >= 0);

  return (
    <div>
      <PageHeader
        title={`Good to see you, ${(profile?.full_name || "there").split(" ")[0]}`}
        description={`${ROLE_LABEL[role]} view. Everything below reflects what your role is allowed to see.`}
        action={
          <Badge variant="secondary" className="rounded-full px-3 py-1">
            {ROLE_LABEL[role]}
          </Badge>
        }
      />

      {loading ? (
        <CardsSkeleton />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatTile
              label={role === "student" ? "My attendance" : "Marked records"}
              value={role === "student" ? `${percent}%` : (attendance.data ?? []).length}
              hint={`${(attendance.data ?? []).length} records visible`}
            />
            <StatTile
              label="Open assignments"
              value={openAssignments.length}
              hint="Deadline still ahead"
            />
            <StatTile
              label="Upcoming events"
              value={upcomingEvents.length}
              hint="Registration may be open"
            />
            <StatTile
              label="Live placement drives"
              value={openDrives.length}
              hint="Applications accepted"
            />
          </div>

          <div className="mt-6 grid gap-5 lg:grid-cols-2">
            <Card className="border-border/70">
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="text-base">Next deadlines</CardTitle>
                <Button asChild variant="ghost" size="sm">
                  <Link to="/assignments">All assignments</Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {openAssignments.slice(0, 4).map((item) => (
                  <div key={item.id as string} className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">{item.title as string}</p>
                      <p className="text-xs text-muted-foreground">
                        {(item.courses as { code: string } | null)?.code ?? "Course"} ·{" "}
                        {formatDate(item.deadline as string)}
                      </p>
                    </div>
                    <Badge variant="outline">{daysUntil(item.deadline as string)}d</Badge>
                  </div>
                ))}
                {openAssignments.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nothing due right now.</p>
                ) : null}
              </CardContent>
            </Card>

            <Card className="border-border/70">
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="text-base">Campus notices</CardTitle>
                <Button asChild variant="ghost" size="sm">
                  <Link to="/announcements">All notices</Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {(announcements.data ?? []).slice(0, 4).map((item) => (
                  <div key={item.id as string}>
                    <p className="text-sm font-medium">{item.title as string}</p>
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                      {item.body as string}
                    </p>
                  </div>
                ))}
                {(announcements.data ?? []).length === 0 ? (
                  <p className="text-sm text-muted-foreground">No notices posted.</p>
                ) : null}
              </CardContent>
            </Card>

            <Card className="border-border/70 lg:col-span-2">
              <CardHeader className="flex-row items-center justify-between">
                <CardTitle className="text-base">What's on soon</CardTitle>
                <Button asChild variant="ghost" size="sm">
                  <Link to="/events">All events</Link>
                </Button>
              </CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {upcomingEvents.slice(0, 3).map((item) => (
                  <div key={item.id as string} className="rounded-md border border-border/60 p-4">
                    <p className="text-sm font-medium">{item.title as string}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {item.venue as string} · {formatDate(item.starts_at as string)}
                    </p>
                  </div>
                ))}
                {upcomingEvents.length === 0 ? (
                  <p className="text-sm text-muted-foreground">The calendar is clear.</p>
                ) : null}
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
