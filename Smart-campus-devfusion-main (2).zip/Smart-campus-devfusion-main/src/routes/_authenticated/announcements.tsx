import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Card, CardContent } from "@/components/ui/card";
import { fetchAnnouncements } from "@/lib/campus";

export const Route = createFileRoute("/_authenticated/announcements")({
  component: AnnouncementsPage,
});

function AnnouncementsPage() {
  const query = useQuery({ queryKey: ["announcements"], queryFn: fetchAnnouncements });
  const rows = (query.data ?? []) as Record<string, unknown>[];

  return (
    <div>
      <PageHeader
        title="Announcements"
        description="Official notices from departments and the campus office."
      />
      {query.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="This section fills up as the campus team publishes records."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row, index) => (
            <Card key={(row["id"] as string) ?? index} className="border-border/70">
              <CardContent className="space-y-2 p-5">
                <p className="font-medium">
                  {(row["title"] as string) ??
                    (row["name"] as string) ??
                    (row["role_title"] as string) ??
                    "Record"}
                </p>
                <p className="line-clamp-3 text-sm text-muted-foreground">
                  {(row["description"] as string) ??
                    (row["body"] as string) ??
                    (row["company"] as string) ??
                    ""}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
