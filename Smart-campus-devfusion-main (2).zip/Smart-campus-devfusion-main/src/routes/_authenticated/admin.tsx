import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, StatTile, EmptyState } from "@/components/campus/states";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import {
  createAnnouncement,
  fetchAllProfiles,
  fetchAnnouncements,
  fetchCourses,
  fetchDepartments,
  fetchEvents,
  fetchPlacements,
  revokeUserAccess,
  setUserRole,
  updateStudentPerformance,
  type AdminUserRow,
} from "@/lib/campus";
import { ROLES, ROLE_LABEL, type Role } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminPage,
});

function AdminPage() {
  const { roles, ready } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (ready && !roles.includes("admin")) {
      void navigate({ to: "/dashboard" });
    }
  }, [ready, roles, navigate]);

  if (!ready || !roles.includes("admin")) {
    return null;
  }

  return (
    <div>
      <PageHeader
        title="Admin panel"
        description="Manage institution records, user roles, student performance and campus announcements."
      />
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users &amp; performance</TabsTrigger>
          <TabsTrigger value="announcements">Post announcement</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>
        <TabsContent value="users">
          <UsersTab />
        </TabsContent>
        <TabsContent value="announcements">
          <AnnouncementTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function OverviewTab() {
  const departments = useQuery({ queryKey: ["departments"], queryFn: fetchDepartments });
  const courses = useQuery({ queryKey: ["courses"], queryFn: fetchCourses });
  const events = useQuery({ queryKey: ["events"], queryFn: fetchEvents });
  const placements = useQuery({ queryKey: ["placements"], queryFn: fetchPlacements });
  const announcements = useQuery({ queryKey: ["announcements"], queryFn: fetchAnnouncements });
  const profiles = useQuery({ queryKey: ["admin-profiles"], queryFn: fetchAllProfiles });

  const loading = departments.isLoading || courses.isLoading || profiles.isLoading;

  return loading ? (
    <div className="pt-4">
      <CardsSkeleton count={3} />
    </div>
  ) : (
    <div className="grid gap-4 pt-4 sm:grid-cols-2 lg:grid-cols-3">
      <StatTile label="Departments" value={(departments.data ?? []).length} />
      <StatTile label="Courses" value={(courses.data ?? []).length} />
      <StatTile label="Events" value={(events.data ?? []).length} />
      <StatTile label="Placement drives" value={(placements.data ?? []).length} />
      <StatTile label="Announcements" value={(announcements.data ?? []).length} />
      <StatTile label="Registered users" value={(profiles.data ?? []).length} />
    </div>
  );
}

function UsersTab() {
  const queryClient = useQueryClient();
  const { user: currentUser } = useAuth();
  const profiles = useQuery({ queryKey: ["admin-profiles"], queryFn: fetchAllProfiles });
  const [drafts, setDrafts] = useState<
    Record<string, { cgpa: string; semester: string; is_approved: boolean }>
  >({});

  function draftFor(row: AdminUserRow) {
    return (
      drafts[row.id] ?? {
        cgpa: row.cgpa != null ? String(row.cgpa) : "",
        semester: row.semester != null ? String(row.semester) : "",
        is_approved: row.is_approved,
      }
    );
  }

  const performanceMutation = useMutation({
    mutationFn: (input: {
      userId: string;
      cgpa: number | null;
      semester: number | null;
      is_approved: boolean;
    }) =>
      updateStudentPerformance(input.userId, {
        cgpa: input.cgpa,
        semester: input.semester,
        is_approved: input.is_approved,
      }),
    onSuccess: () => {
      toast.success("Student performance updated");
      void queryClient.invalidateQueries({ queryKey: ["admin-profiles"] });
    },
    onError: () => toast.error("Could not update performance"),
  });

  const roleMutation = useMutation({
    mutationFn: (input: { userId: string; role: Role; grant: boolean }) =>
      setUserRole(input.userId, input.role, input.grant),
    onSuccess: () => {
      toast.success("Role updated");
      void queryClient.invalidateQueries({ queryKey: ["admin-profiles"] });
    },
    onError: () => toast.error("Could not update role"),
  });

  const revokeMutation = useMutation({
    mutationFn: (userId: string) => revokeUserAccess(userId),
    onSuccess: () => {
      toast.success("User access revoked");
      void queryClient.invalidateQueries({ queryKey: ["admin-profiles"] });
    },
    onError: () => toast.error("Could not revoke access"),
  });

  const rows = profiles.data ?? [];

  return (
    <div className="space-y-4 pt-4">
      {profiles.isLoading ? (
        <CardsSkeleton count={3} />
      ) : rows.length === 0 ? (
        <EmptyState title="No users yet" description="Accounts appear here once people sign up." />
      ) : (
        rows.map((row) => {
          const draft = draftFor(row);
          return (
            <Card key={row.id} className="border-border/70">
              <CardContent className="grid gap-4 p-5 lg:grid-cols-[1.4fr_1fr_1fr] lg:items-end">
                <div>
                  <p className="font-medium">{row.full_name || "Unnamed user"}</p>
                  <p className="text-sm text-muted-foreground">{row.email}</p>
                  {row.roll_number ? (
                    <p className="text-xs text-muted-foreground">Roll no. {row.roll_number}</p>
                  ) : null}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {ROLES.map((role) => {
                      const active = row.roles.includes(role);
                      return (
                        <button
                          key={role}
                          type="button"
                          onClick={() =>
                            roleMutation.mutate({ userId: row.id, role, grant: !active })
                          }
                          disabled={role === "student" && active && row.roles.length === 1}
                          className={`rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                            active
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-border text-muted-foreground hover:border-primary/50"
                          }`}
                        >
                          {ROLE_LABEL[role]}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">CGPA (student performance)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min={0}
                    max={10}
                    value={draft.cgpa}
                    placeholder="e.g. 8.40"
                    onChange={(event) =>
                      setDrafts((prev) => ({
                        ...prev,
                        [row.id]: { ...draft, cgpa: event.target.value },
                      }))
                    }
                  />
                  <Label className="text-xs">Semester</Label>
                  <Input
                    type="number"
                    min={1}
                    max={8}
                    value={draft.semester}
                    onChange={(event) =>
                      setDrafts((prev) => ({
                        ...prev,
                        [row.id]: { ...draft, semester: event.target.value },
                      }))
                    }
                  />
                  <div className="flex items-center gap-2 pt-1">
                    <Switch
                      checked={draft.is_approved}
                      onCheckedChange={(checked) =>
                        setDrafts((prev) => ({
                          ...prev,
                          [row.id]: { ...draft, is_approved: checked },
                        }))
                      }
                    />
                    <span className="text-xs text-muted-foreground">Approved / active</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2 lg:items-end">
                  <Button
                    size="sm"
                    onClick={() =>
                      performanceMutation.mutate({
                        userId: row.id,
                        cgpa: draft.cgpa === "" ? null : Number(draft.cgpa),
                        semester: draft.semester === "" ? null : Number(draft.semester),
                        is_approved: draft.is_approved,
                      })
                    }
                    disabled={performanceMutation.isPending}
                  >
                    Save performance
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => revokeMutation.mutate(row.id)}
                    disabled={revokeMutation.isPending || row.id === currentUser?.id}
                  >
                    Revoke access
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })
      )}
    </div>
  );
}

function AnnouncementTab() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [pinned, setPinned] = useState(false);

  const announcements = useQuery({ queryKey: ["announcements"], queryFn: fetchAnnouncements });

  const postMutation = useMutation({
    mutationFn: () => {
      if (!user) throw new Error("Not signed in");
      return createAnnouncement({
        title: title.trim(),
        body: body.trim(),
        is_pinned: pinned,
        authorId: user.id,
      });
    },
    onSuccess: () => {
      toast.success("Announcement posted");
      setTitle("");
      setBody("");
      setPinned(false);
      void queryClient.invalidateQueries({ queryKey: ["announcements"] });
    },
    onError: () => toast.error("Could not post announcement"),
  });

  return (
    <div className="grid gap-6 pt-4 lg:grid-cols-[1fr_1fr]">
      <Card className="border-border/70">
        <CardHeader>
          <CardTitle className="text-base">New announcement</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ann-title">Title</Label>
            <Input
              id="ann-title"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Mid-semester exam schedule released"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ann-body">Details</Label>
            <Textarea
              id="ann-body"
              value={body}
              onChange={(event) => setBody(event.target.value)}
              rows={6}
              placeholder="Write the full notice for students and faculty..."
            />
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={pinned} onCheckedChange={setPinned} />
            <span className="text-sm text-muted-foreground">Pin to top</span>
          </div>
          <Button
            onClick={() => postMutation.mutate()}
            disabled={postMutation.isPending || !title.trim() || !body.trim()}
          >
            {postMutation.isPending ? "Posting..." : "Post announcement"}
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <p className="text-sm font-medium text-muted-foreground">Recent announcements</p>
        {(announcements.data ?? []).slice(0, 6).map((row) => {
          const record = row as Record<string, unknown>;
          return (
            <Card key={record["id"] as string} className="border-border/70">
              <CardContent className="space-y-1 p-4">
                <p className="text-sm font-medium">{record["title"] as string}</p>
                <p className="line-clamp-2 text-xs text-muted-foreground">
                  {record["body"] as string}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
