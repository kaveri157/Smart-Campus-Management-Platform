import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { PageHeader } from "@/components/campus/page-header";
import { EmptyState } from "@/components/campus/states";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { fetchAnnouncements, fetchCourses, fetchEvents } from "@/lib/campus";

export const Route = createFileRoute("/_authenticated/search")({
  component: SearchPage,
});

function SearchPage() {
  const [term, setTerm] = useState("");
  const courses = useQuery({ queryKey: ["courses"], queryFn: fetchCourses });
  const events = useQuery({ queryKey: ["events"], queryFn: fetchEvents });
  const announcements = useQuery({ queryKey: ["announcements"], queryFn: fetchAnnouncements });

  const needle = term.trim().toLowerCase();
  const results = [
    ...(courses.data ?? []).map((c) => ({
      id: c.id,
      label: `${c.code} — ${c.title}`,
      kind: "Course",
    })),
    ...(events.data ?? []).map((e) => ({
      id: e.id as string,
      label: e.title as string,
      kind: "Event",
    })),
    ...(announcements.data ?? []).map((a) => ({
      id: a.id as string,
      label: a.title as string,
      kind: "Notice",
    })),
  ].filter((item) => needle.length > 1 && item.label.toLowerCase().includes(needle));

  return (
    <div>
      <PageHeader title="Search" description="Look across courses, events and notices at once." />
      <Input
        value={term}
        onChange={(event) => setTerm(event.target.value)}
        placeholder="Try a course code, event or notice"
        className="max-w-xl"
      />
      <div className="mt-6 space-y-3">
        {results.map((item) => (
          <Card key={`${item.kind}-${item.id}`} className="border-border/70">
            <CardContent className="flex items-center justify-between gap-4 p-4">
              <span className="text-sm font-medium">{item.label}</span>
              <span className="text-xs text-muted-foreground">{item.kind}</span>
            </CardContent>
          </Card>
        ))}
        {needle.length > 1 && results.length === 0 ? (
          <EmptyState title="No matches" description="Try a shorter phrase or a course code." />
        ) : null}
      </div>
    </div>
  );
}
