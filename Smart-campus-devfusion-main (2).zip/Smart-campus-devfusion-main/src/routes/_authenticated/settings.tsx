import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { deleteOwnAccount, fetchUserSettings, upsertUserSettings } from "@/lib/campus";
import { useTheme } from "@/lib/theme";

export const Route = createFileRoute("/_authenticated/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { theme, toggle, set } = useTheme();
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const settings = useQuery({
    queryKey: ["user-settings", user?.id],
    queryFn: () => fetchUserSettings(user!.id),
    enabled: !!user,
  });

  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(false);
  const [visibility, setVisibility] = useState("campus");

  useEffect(() => {
    if (!settings.data) return;
    setEmailNotifications(settings.data.email_notifications);
    setPushNotifications(settings.data.push_notifications);
    setVisibility(settings.data.profile_visibility);
    if (settings.data.theme === "light" || settings.data.theme === "dark") set(settings.data.theme);
  }, [settings.data, set]);

  const saveMutation = useMutation({
    mutationFn: () =>
      upsertUserSettings({
        user_id: user!.id,
        theme,
        email_notifications: emailNotifications,
        push_notifications: pushNotifications,
        profile_visibility: visibility,
      }),
    onSuccess: () => {
      toast.success("Preferences saved");
      void queryClient.invalidateQueries({ queryKey: ["user-settings", user?.id] });
    },
    onError: () => toast.error("Could not save preferences"),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await deleteOwnAccount(user!.id);
      await supabase.auth.signOut();
    },
    onSuccess: () => {
      toast.success("Account deactivated");
      void navigate({ to: "/auth" });
    },
    onError: () => toast.error("Could not delete account"),
  });

  return (
    <div>
      <PageHeader title="Settings" description="Preferences stored on your account." />
      <div className="max-w-2xl space-y-6">
        <Card className="border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Appearance</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              Currently using the {theme === "dark" ? "dark" : "light"} palette.
            </p>
            <Button variant="outline" onClick={toggle}>
              Switch theme
            </Button>
          </CardContent>
        </Card>

        <Card className="border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Notification preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Email notifications</span>
              <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Push notifications</span>
              <Switch checked={pushNotifications} onCheckedChange={setPushNotifications} />
            </div>
            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground">Profile visibility</span>
              <Select value={visibility} onValueChange={setVisibility}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="campus">Campus</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
              Save preferences
            </Button>
          </CardContent>
        </Card>

        <Card className="border-destructive/40">
          <CardHeader>
            <CardTitle className="text-base text-destructive">Delete account</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This deactivates your account, removes your roles and signs you out. Contact an
              administrator for full removal.
            </p>
            <Button
              variant="destructive"
              onClick={() => deleteMutation.mutate()}
              disabled={deleteMutation.isPending}
            >
              Delete my account
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
