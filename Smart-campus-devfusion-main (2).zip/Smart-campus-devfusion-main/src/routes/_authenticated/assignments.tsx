import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import {
  createAssignment,
  daysUntil,
  fetchAssignments,
  fetchCourses,
  fetchSubmissions,
  formatDate,
  gradeSubmission,
  submitAssignment,
} from "@/lib/campus";
import { isStaff } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/assignments")({
  component: AssignmentsPage,
});

function AssignmentsPage() {
  const { roles, user } = useAuth();
  const staff = isStaff(roles);
  const queryClient = useQueryClient();

  const courses = useQuery({ queryKey: ["courses"], queryFn: fetchCourses });
  const assignments = useQuery({ queryKey: ["assignments"], queryFn: fetchAssignments });
  const submissions = useQuery({
    queryKey: ["submissions"],
    queryFn: fetchSubmissions,
    enabled: staff,
  });

  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [maxMarks, setMaxMarks] = useState("100");
  const [deadline, setDeadline] = useState("");

  const createMutation = useMutation({
    mutationFn: () => {
      if (!user) throw new Error("Not signed in");
      if (!courseId || !title.trim() || !deadline)
        throw new Error("Course, title and deadline are required.");
      return createAssignment({
        course_id: courseId,
        faculty_id: user.id,
        title: title.trim(),
        description: description.trim(),
        max_marks: Number(maxMarks) || 100,
        deadline: new Date(deadline).toISOString(),
      });
    },
    onSuccess: () => {
      toast.success("Assignment published");
      setTitle("");
      setDescription("");
      setDeadline("");
      void queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const rows = (assignments.data ?? []) as Record<string, unknown>[];

  return (
    <div>
      <PageHeader
        title="Assignments"
        description={
          staff
            ? "Publish briefs with a deadline, then review and grade submissions below."
            : "Briefs, deadlines and submissions for your courses."
        }
      />

      {staff ? (
        <Card className="mb-6 border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Publish an assignment</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2 lg:col-span-2">
              <Label>Course</Label>
              <Select value={courseId} onValueChange={setCourseId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a course" />
                </SelectTrigger>
                <SelectContent>
                  {(courses.data ?? []).map((course) => (
                    <SelectItem key={course.id} value={course.id}>
                      {course.code} — {course.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="a-title">Title</Label>
              <Input id="a-title" value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-2 lg:col-span-3">
              <Label htmlFor="a-desc">Description / rubric</Label>
              <Textarea
                id="a-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="a-marks">Max marks</Label>
              <Input
                id="a-marks"
                type="number"
                value={maxMarks}
                onChange={(e) => setMaxMarks(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="a-deadline">Deadline</Label>
              <Input
                id="a-deadline"
                type="datetime-local"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
            <div className="sm:col-span-2 lg:col-span-4">
              <Button onClick={() => createMutation.mutate()} disabled={createMutation.isPending}>
                Publish
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {assignments.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="Assignments published by faculty will appear here."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => (
            <AssignmentCard
              key={row["id"] as string}
              row={row}
              staff={staff}
              userId={user?.id ?? ""}
              submissions={(submissions.data ?? []) as Record<string, unknown>[]}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function AssignmentCard({
  row,
  staff,
  userId,
  submissions,
}: {
  row: Record<string, unknown>;
  staff: boolean;
  userId: string;
  submissions: Record<string, unknown>[];
}) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [githubUrl, setGithubUrl] = useState("");
  const [fileUrl, setFileUrl] = useState("");
  const [notes, setNotes] = useState("");

  const assignmentId = row["id"] as string;
  const deadline = row["deadline"] as string;
  const overdue = daysUntil(deadline) < 0;
  const course = row["courses"] as { code: string; title: string } | null;

  const mine = submissions.filter((s) => s["assignment_id"] === assignmentId);
  const myOwn = mine.find((s) => (s["student_id"] as string) === userId);

  const submitMutation = useMutation({
    mutationFn: () =>
      submitAssignment({
        assignment_id: assignmentId,
        student_id: userId,
        github_url: githubUrl.trim() || null,
        file_url: fileUrl.trim() || null,
        notes: notes.trim() || null,
        is_late: overdue,
      }),
    onSuccess: () => {
      toast.success("Submission saved");
      setOpen(false);
      void queryClient.invalidateQueries({ queryKey: ["submissions"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <Card className="border-border/70">
      <CardContent className="space-y-3 p-5">
        <div className="flex items-start justify-between gap-2">
          <p className="font-medium">{row["title"] as string}</p>
          <Badge variant={overdue ? "destructive" : "secondary"}>
            {overdue ? "Closed" : `${daysUntil(deadline)}d left`}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground">
          {course ? `${course.code} — ${course.title}` : "Course"} · Due {formatDate(deadline)}
        </p>
        <p className="line-clamp-3 text-sm text-muted-foreground">
          {(row["description"] as string) ?? ""}
        </p>

        {!staff ? (
          myOwn ? (
            <div className="rounded-md border border-border/60 p-3 text-xs">
              <p className="font-medium text-foreground">
                Submitted{(myOwn["is_late"] as boolean) ? " (late)" : ""}
              </p>
              {myOwn["marks"] != null ? (
                <p className="mt-1 text-muted-foreground">
                  Marks: {myOwn["marks"] as number} / {row["max_marks"] as number}
                  {myOwn["feedback"] ? ` — ${myOwn["feedback"] as string}` : ""}
                </p>
              ) : (
                <p className="mt-1 text-muted-foreground">Awaiting review.</p>
              )}
            </div>
          ) : open ? (
            <div className="space-y-2">
              <Input
                placeholder="GitHub link"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
              />
              <Input
                placeholder="File / drive link"
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
              />
              <Textarea
                placeholder="Notes for the reviewer"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
              />
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => submitMutation.mutate()}
                  disabled={submitMutation.isPending}
                >
                  Submit
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button size="sm" variant="outline" onClick={() => setOpen(true)}>
              Submit solution
            </Button>
          )
        ) : (
          <StaffSubmissionsList submissions={mine} maxMarks={row["max_marks"] as number} />
        )}
      </CardContent>
    </Card>
  );
}

function StaffSubmissionsList({
  submissions,
  maxMarks,
}: {
  submissions: Record<string, unknown>[];
  maxMarks: number;
}) {
  const queryClient = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, { marks: string; feedback: string }>>({});

  const gradeMutation = useMutation({
    mutationFn: (input: { id: string; marks: number; feedback: string }) =>
      gradeSubmission(input.id, input.marks, input.feedback),
    onSuccess: () => {
      toast.success("Grade saved");
      void queryClient.invalidateQueries({ queryKey: ["submissions"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  if (submissions.length === 0) {
    return <p className="text-xs text-muted-foreground">No submissions yet.</p>;
  }

  return (
    <div className="space-y-2">
      {submissions.map((sub) => {
        const id = sub["id"] as string;
        const profile = sub["profiles"] as { full_name: string; roll_number: string | null } | null;
        const draft = drafts[id] ?? {
          marks: sub["marks"] != null ? String(sub["marks"]) : "",
          feedback: (sub["feedback"] as string) ?? "",
        };
        return (
          <div key={id} className="rounded-md border border-border/60 p-2 text-xs">
            <p className="font-medium text-foreground">
              {profile?.full_name ?? "Student"}{" "}
              {profile?.roll_number ? `(${profile.roll_number})` : ""}
            </p>
            <div className="mt-2 flex items-center gap-2">
              <Input
                className="h-7 w-20 text-xs"
                type="number"
                max={maxMarks}
                placeholder="Marks"
                value={draft.marks}
                onChange={(e) =>
                  setDrafts((prev) => ({ ...prev, [id]: { ...draft, marks: e.target.value } }))
                }
              />
              <Input
                className="h-7 flex-1 text-xs"
                placeholder="Feedback"
                value={draft.feedback}
                onChange={(e) =>
                  setDrafts((prev) => ({ ...prev, [id]: { ...draft, feedback: e.target.value } }))
                }
              />
              <Button
                size="sm"
                className="h-7 px-2 text-xs"
                onClick={() =>
                  gradeMutation.mutate({
                    id,
                    marks: Number(draft.marks) || 0,
                    feedback: draft.feedback,
                  })
                }
                disabled={gradeMutation.isPending}
              >
                Save
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
