import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { fetchDepartments, updateProfile } from "@/lib/campus";
import { ROLE_LABEL } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const { profile, role, user, refreshProfile } = useAuth();
  const departments = useQuery({ queryKey: ["departments"], queryFn: fetchDepartments });

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [semester, setSemester] = useState("");
  const [skills, setSkills] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [github, setGithub] = useState("");
  const [resume, setResume] = useState("");
  const [bio, setBio] = useState("");

  useEffect(() => {
    if (!profile) return;
    setFullName(profile.full_name ?? "");
    setPhone(profile.phone ?? "");
    setRollNumber(profile.roll_number ?? "");
    setDepartmentId(profile.department_id ?? "");
    setSemester(profile.semester != null ? String(profile.semester) : "");
    setSkills((profile.skills ?? []).join(", "));
    setLinkedin(profile.linkedin_url ?? "");
    setGithub(profile.github_url ?? "");
    setResume(profile.resume_url ?? "");
    setBio(profile.bio ?? "");
  }, [profile]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Not signed in");
      await updateProfile(user.id, {
        full_name: fullName.trim(),
        phone: phone.trim() || null,
        roll_number: rollNumber.trim() || null,
        department_id: departmentId || null,
        semester: semester === "" ? null : Number(semester),
        skills: skills
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        linkedin_url: linkedin.trim() || null,
        github_url: github.trim() || null,
        resume_url: resume.trim() || null,
        bio: bio.trim() || null,
      });
    },
    onSuccess: async () => {
      toast.success("Profile updated");
      await refreshProfile();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <div>
      <PageHeader title="Profile" description="Details linked to your campus account." />
      <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
        <Card className="h-fit border-border/70">
          <CardContent className="divide-y divide-border/60 p-0">
            {[
              ["Email", user?.email ?? "—"],
              ["Role", ROLE_LABEL[role]],
            ].map(([label, value]) => (
              <div key={label} className="flex items-center justify-between gap-4 px-6 py-4">
                <span className="text-sm text-muted-foreground">{label}</span>
                <span className="text-sm font-medium">{value}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Edit details</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="p-name">Full name</Label>
              <Input id="p-name" value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-phone">Phone</Label>
              <Input id="p-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-roll">Roll number</Label>
              <Input
                id="p-roll"
                value={rollNumber}
                onChange={(e) => setRollNumber(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Department</Label>
              <Select value={departmentId} onValueChange={setDepartmentId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {(departments.data ?? []).map((dept) => (
                    <SelectItem key={dept.id as string} value={dept.id as string}>
                      {dept.name as string}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-sem">Semester</Label>
              <Input
                id="p-sem"
                type="number"
                min={1}
                max={8}
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-skills">Skills (comma separated)</Label>
              <Input id="p-skills" value={skills} onChange={(e) => setSkills(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-linkedin">LinkedIn</Label>
              <Input
                id="p-linkedin"
                value={linkedin}
                onChange={(e) => setLinkedin(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-github">GitHub</Label>
              <Input id="p-github" value={github} onChange={(e) => setGithub(e.target.value)} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="p-resume">Resume link</Label>
              <Input
                id="p-resume"
                value={resume}
                onChange={(e) => setResume(e.target.value)}
                placeholder="https://..."
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="p-bio">Bio</Label>
              <Textarea id="p-bio" value={bio} onChange={(e) => setBio(e.target.value)} rows={3} />
            </div>
            <div className="sm:col-span-2">
              <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
                Save changes
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
