import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import {
  deleteNotification,
  fetchNotifications,
  formatDateTime,
  markAllNotificationsRead,
  markNotificationRead,
} from "@/lib/campus";

export const Route = createFileRoute("/_authenticated/notifications")({
  component: NotificationsPage,
});

function NotificationsPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const query = useQuery({ queryKey: ["notifications"], queryFn: fetchNotifications });
  const rows = (query.data ?? []) as Record<string, unknown>[];
  const unread = rows.filter((r) => !(r["is_read"] as boolean)).length;

  const markAllMutation = useMutation({
    mutationFn: () => markAllNotificationsRead(user!.id),
    onSuccess: () => {
      toast.success("All caught up");
      void queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });

  const readMutation = useMutation({
    mutationFn: (id: string) => markNotificationRead(id),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteNotification(id),
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["notifications"] }),
  });

  return (
    <div>
      <PageHeader
        title="Notifications"
        description="Everything addressed to you, newest first."
        action={
          unread > 0 ? (
            <Button
              size="sm"
              variant="outline"
              onClick={() => markAllMutation.mutate()}
              disabled={markAllMutation.isPending}
            >
              Mark all read ({unread})
            </Button>
          ) : undefined
        }
      />
      {query.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="Notifications about assignments, attendance and events will land here."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => {
            const id = row["id"] as string;
            const isRead = row["is_read"] as boolean;
            return (
              <Card key={id} className={`border-border/70 ${isRead ? "" : "border-primary/40"}`}>
                <CardContent className="space-y-2 p-5">
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-medium">{row["title"] as string}</p>
                    {!isRead ? <Badge className="shrink-0">New</Badge> : null}
                  </div>
                  <p className="line-clamp-3 text-sm text-muted-foreground">
                    {(row["body"] as string) ?? ""}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDateTime(row["created_at"] as string)}
                  </p>
                  <div className="flex gap-2 pt-1">
                    {!isRead ? (
                      <Button size="sm" variant="ghost" onClick={() => readMutation.mutate(id)}>
                        Mark read
                      </Button>
                    ) : null}
                    <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(id)}>
                      Dismiss
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
