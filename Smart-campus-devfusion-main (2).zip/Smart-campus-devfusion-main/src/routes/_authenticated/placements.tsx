import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import {
  applyToPlacement,
  createPlacement,
  daysUntil,
  fetchMyApplications,
  fetchPlacements,
  formatDate,
  withdrawApplication,
} from "@/lib/campus";
import { canManageCampus } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/placements")({
  component: PlacementsPage,
});

function PlacementsPage() {
  const { roles, user, profile } = useAuth();
  const manager = canManageCampus(roles);
  const queryClient = useQueryClient();

  const placements = useQuery({ queryKey: ["placements"], queryFn: fetchPlacements });
  const applications = useQuery({ queryKey: ["my-applications"], queryFn: fetchMyApplications });

  const [company, setCompany] = useState("");
  const [roleTitle, setRoleTitle] = useState("");
  const [description, setDescription] = useState("");
  const [ctc, setCtc] = useState("");
  const [eligibility, setEligibility] = useState("");
  const [minCgpa, setMinCgpa] = useState("");
  const [deadline, setDeadline] = useState("");

  const createMutation = useMutation({
    mutationFn: () => {
      if (!user) throw new Error("Not signed in");
      if (!company.trim() || !roleTitle.trim() || !deadline)
        throw new Error("Company, role and deadline are required.");
      return createPlacement({
        company: company.trim(),
        role_title: roleTitle.trim(),
        description: description.trim(),
        ctc: ctc.trim(),
        eligibility: eligibility.trim(),
        min_cgpa: minCgpa === "" ? null : Number(minCgpa),
        deadline: new Date(deadline).toISOString(),
        created_by: user.id,
      });
    },
    onSuccess: () => {
      toast.success("Placement drive posted");
      setCompany("");
      setRoleTitle("");
      setDescription("");
      setCtc("");
      setEligibility("");
      setMinCgpa("");
      setDeadline("");
      void queryClient.invalidateQueries({ queryKey: ["placements"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const rows = (placements.data ?? []) as Record<string, unknown>[];
  const myApps = new Map(
    (applications.data ?? []).map((a) => [
      (a as Record<string, unknown>)["placement_id"] as string,
      a as Record<string, unknown>,
    ]),
  );

  return (
    <div>
      <PageHeader
        title="Placements"
        description={
          manager
            ? "Post drives and track applications."
            : "Drives, eligibility and application windows."
        }
      />

      {manager ? (
        <Card className="mb-6 border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Post a placement drive</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="p-company">Company</Label>
              <Input id="p-company" value={company} onChange={(e) => setCompany(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-role">Role</Label>
              <Input id="p-role" value={roleTitle} onChange={(e) => setRoleTitle(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-ctc">CTC</Label>
              <Input
                id="p-ctc"
                value={ctc}
                onChange={(e) => setCtc(e.target.value)}
                placeholder="e.g. 12 LPA"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-cgpa">Min CGPA</Label>
              <Input
                id="p-cgpa"
                type="number"
                step="0.1"
                value={minCgpa}
                onChange={(e) => setMinCgpa(e.target.value)}
              />
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="p-eligibility">Eligibility</Label>
              <Input
                id="p-eligibility"
                value={eligibility}
                onChange={(e) => setEligibility(e.target.value)}
              />
            </div>
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="p-deadline">Deadline</Label>
              <Input
                id="p-deadline"
                type="datetime-local"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
              />
            </div>
            <div className="lg:col-span-4 space-y-2">
              <Label htmlFor="p-desc">Description</Label>
              <Textarea
                id="p-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="sm:col-span-2 lg:col-span-4">
              <Button onClick={() => createMutation.mutate()} disabled={createMutation.isPending}>
                Post drive
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {placements.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="Placement drives will appear here once posted."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => {
            const id = row["id"] as string;
            const closed = daysUntil(row["deadline"] as string) < 0;
            const application = myApps.get(id);
            return (
              <Card key={id} className="border-border/70">
                <CardContent className="space-y-2 p-5">
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-medium">{row["company"] as string}</p>
                    <Badge variant={closed ? "destructive" : "secondary"}>
                      {closed ? "Closed" : "Open"}
                    </Badge>
                  </div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {row["role_title"] as string}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {(row["ctc"] as string) || "CTC N/A"} · Apply by{" "}
                    {formatDate(row["deadline"] as string)}
                  </p>
                  <p className="line-clamp-2 text-xs text-muted-foreground">
                    {(row["eligibility"] as string) ?? ""}
                  </p>

                  {!manager ? (
                    application ? (
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <Badge variant="outline" className="capitalize">
                          {application["status"] as string}
                        </Badge>
                        <ApplyActions applied onWithdraw={() => withdraw(id)} />
                      </div>
                    ) : (
                      <ApplyActions
                        applied={false}
                        onApply={() =>
                          applyToPlacement(id, user!.id, profile?.resume_url ?? null)
                            .then(() => {
                              toast.success("Applied");
                              void queryClient.invalidateQueries({ queryKey: ["my-applications"] });
                            })
                            .catch((error: Error) => toast.error(error.message))
                        }
                        disabled={closed}
                      />
                    )
                  ) : null}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );

  function withdraw(placementId: string) {
    if (!user) return;
    withdrawApplication(placementId, user.id)
      .then(() => {
        toast.success("Application withdrawn");
        void queryClient.invalidateQueries({ queryKey: ["my-applications"] });
      })
      .catch((error: Error) => toast.error(error.message));
  }
}

function ApplyActions({
  applied,
  onApply,
  onWithdraw,
  disabled,
}: {
  applied: boolean;
  onApply?: () => void;
  onWithdraw?: () => void;
  disabled?: boolean;
}) {
  if (applied) {
    return (
      <Button size="sm" variant="outline" onClick={onWithdraw}>
        Withdraw
      </Button>
    );
  }
  return (
    <Button size="sm" onClick={onApply} disabled={disabled}>
      Apply
    </Button>
  );
}
