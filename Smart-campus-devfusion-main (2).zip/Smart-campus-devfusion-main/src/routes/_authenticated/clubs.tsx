import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/campus/page-header";
import { CardsSkeleton, EmptyState } from "@/components/campus/states";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/use-auth";
import { createClub, fetchClubMemberships, fetchClubs, joinClub, leaveClub } from "@/lib/campus";
import { canManageCampus } from "@/lib/roles";

export const Route = createFileRoute("/_authenticated/clubs")({
  component: ClubsPage,
});

function ClubsPage() {
  const { roles, user } = useAuth();
  const manager = canManageCampus(roles);
  const queryClient = useQueryClient();

  const clubs = useQuery({ queryKey: ["clubs"], queryFn: fetchClubs });
  const memberships = useQuery({ queryKey: ["club-memberships"], queryFn: fetchClubMemberships });

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");

  const createMutation = useMutation({
    mutationFn: () => {
      if (!user) throw new Error("Not signed in");
      if (!name.trim()) throw new Error("Name is required.");
      return createClub({
        name: name.trim(),
        description: description.trim(),
        category: category.trim() || "general",
        lead_id: user.id,
      });
    },
    onSuccess: () => {
      toast.success("Club created");
      setName("");
      setCategory("");
      setDescription("");
      void queryClient.invalidateQueries({ queryKey: ["clubs"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const rows = (clubs.data ?? []) as Record<string, unknown>[];
  const myClubIds = new Set(
    (memberships.data ?? []).map((m) => (m as Record<string, unknown>)["club_id"] as string),
  );

  return (
    <div>
      <PageHeader
        title="Clubs"
        description={
          manager
            ? "Create clubs and see who has joined."
            : "Student bodies you can join and follow."
        }
      />

      {manager ? (
        <Card className="mb-6 border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Register a club</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="c-name">Name</Label>
              <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="c-category">Category</Label>
              <Input
                id="c-category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="e.g. technical"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="c-desc">Description</Label>
              <Textarea
                id="c-desc"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="sm:col-span-2">
              <Button onClick={() => createMutation.mutate()} disabled={createMutation.isPending}>
                Create club
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {clubs.isLoading ? (
        <CardsSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing here yet"
          description="Clubs will appear here once registered."
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => {
            const id = row["id"] as string;
            const joined = myClubIds.has(id);
            return (
              <Card key={id} className="border-border/70">
                <CardContent className="space-y-2 p-5">
                  <p className="font-medium">{row["name"] as string}</p>
                  <p className="text-xs uppercase tracking-wide text-muted-foreground">
                    {row["category"] as string}
                  </p>
                  <p className="line-clamp-3 text-sm text-muted-foreground">
                    {(row["description"] as string) ?? ""}
                  </p>
                  <ClubAction clubId={id} userId={user?.id ?? ""} joined={joined} />
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ClubAction({
  clubId,
  userId,
  joined,
}: {
  clubId: string;
  userId: string;
  joined: boolean;
}) {
  const queryClient = useQueryClient();

  const joinMutation = useMutation({
    mutationFn: () => joinClub(clubId, userId),
    onSuccess: () => {
      toast.success("Joined club");
      void queryClient.invalidateQueries({ queryKey: ["club-memberships"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const leaveMutation = useMutation({
    mutationFn: () => leaveClub(clubId, userId),
    onSuccess: () => {
      toast.success("Left club");
      void queryClient.invalidateQueries({ queryKey: ["club-memberships"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return joined ? (
    <Button
      size="sm"
      variant="outline"
      onClick={() => leaveMutation.mutate()}
      disabled={leaveMutation.isPending}
    >
      Leave
    </Button>
  ) : (
    <Button size="sm" onClick={() => joinMutation.mutate()} disabled={joinMutation.isPending}>
      Join
    </Button>
  );
}
