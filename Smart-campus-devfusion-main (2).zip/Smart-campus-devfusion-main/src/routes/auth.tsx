import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { GraduationCap, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in · Smart Campus" },
      {
        name: "description",
        content: "Sign in to Smart Campus with your college email or a Google account to reach your dashboard.",
      },
      { property: "og:title", content: "Sign in · Smart Campus" },
      { property: "og:description", content: "Access the Smart Campus portal for your college." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function AuthPage() {
  const navigate = useNavigate();
  const { session } = useAuth();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);
  const [awaitingConfirm, setAwaitingConfirm] = useState(false);

  useEffect(() => {
    if (session) navigate({ to: "/dashboard", replace: true });
  }, [navigate, session]);

  async function signIn() {
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    navigate({ to: "/dashboard", replace: true });
  }

  async function signUp() {
    if (password.length < 8) {
      toast.error("Use at least 8 characters for the password.");
      return;
    }
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { full_name: fullName.trim() },
      },
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (!data.session) {
      setAwaitingConfirm(true);
      toast.success("Check your inbox to confirm the address before signing in.");
      return;
    }
    navigate({ to: "/dashboard", replace: true });
  }

  async function sendReset() {
    if (!email.trim()) {
      toast.error("Enter the email you registered with.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Reset link sent. It expires in an hour.");
    setMode("signin");
  }

  async function googleSignIn() {
    setBusy(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/dashboard`,
      },
    });
    if (error) {
      setBusy(false);
      toast.error("Google sign-in could not start. Try again.");
      return;
    }
    // On success the browser is redirected to Google, then back to redirectTo — nothing more to do here.
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 py-14">
      <div className="pointer-events-none absolute inset-0 grid-veil opacity-60" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-72 glow-halo" />

      <div className="relative w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <span className="grid size-9 place-items-center rounded-md bg-primary/15 text-primary">
            <GraduationCap className="size-5" />
          </span>
          <span className="font-display text-base font-semibold">Smart Campus</span>
        </Link>

        <Card className="border-border/70 shadow-lift">
          {mode === "forgot" ? (
            <>
              <CardHeader>
                <CardTitle>Reset your password</CardTitle>
                <CardDescription>We'll email a link that opens a page to set a new one.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reset-email">College email</Label>
                  <Input
                    id="reset-email"
                    type="email"
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <Button className="w-full" onClick={sendReset} disabled={busy}>
                  {busy ? <Loader2 className="size-4 animate-spin" /> : "Send reset link"}
                </Button>
                <button
                  type="button"
                  className="w-full text-center text-xs text-muted-foreground hover:text-foreground"
                  onClick={() => setMode("signin")}
                >
                  Back to sign in
                </button>
              </CardContent>
            </>
          ) : awaitingConfirm ? (
            <>
              <CardHeader>
                <CardTitle>Confirm your email</CardTitle>
                <CardDescription>
                  We sent a confirmation link to {email}. Open it, then come back and sign in.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setAwaitingConfirm(false);
                    setMode("signin");
                  }}
                >
                  Return to sign in
                </Button>
              </CardContent>
            </>
          ) : (
            <>
              <CardHeader>
                <CardTitle>Campus portal access</CardTitle>
                <CardDescription>Use your college email, or continue with Google.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="signin">Sign in</TabsTrigger>
                    <TabsTrigger value="signup">Create account</TabsTrigger>
                  </TabsList>

                  <TabsContent value="signin" className="mt-5 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">Password</Label>
                        <button
                          type="button"
                          className="text-xs text-primary hover:underline"
                          onClick={() => setMode("forgot")}
                        >
                          Forgot?
                        </button>
                      </div>
                      <Input
                        id="password"
                        type="password"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") void signIn();
                        }}
                      />
                    </div>
                    <Button className="w-full" onClick={signIn} disabled={busy}>
                      {busy ? <Loader2 className="size-4 animate-spin" /> : "Sign in"}
                    </Button>
                  </TabsContent>

                  <TabsContent value="signup" className="mt-5 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full name</Label>
                      <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">College email</Label>
                      <Input
                        id="signup-email"
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password</Label>
                      <Input
                        id="signup-password"
                        type="password"
                        autoComplete="new-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">Minimum eight characters.</p>
                    </div>
                    <Button className="w-full" onClick={signUp} disabled={busy}>
                      {busy ? <Loader2 className="size-4 animate-spin" /> : "Create account"}
                    </Button>
                  </TabsContent>
                </Tabs>

                <div className="flex items-center gap-3">
                  <span className="h-px flex-1 bg-border" />
                  <span className="text-xs text-muted-foreground">or</span>
                  <span className="h-px flex-1 bg-border" />
                </div>

                <Button variant="outline" className="w-full" onClick={googleSignIn} disabled={busy}>
                  Continue with Google
                </Button>
              </CardContent>
            </>
          )}
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          New accounts start with student access. An administrator can promote a role from the admin panel.
        </p>
      </div>
    </div>
  );
}
