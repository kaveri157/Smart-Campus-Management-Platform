import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password · Smart Campus" },
      { name: "description", content: "Set a new password for your Smart Campus account." },
      { property: "og:title", content: "Choose a new password · Smart Campus" },
      { property: "og:description", content: "Set a new password for your Smart Campus account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [linkValid, setLinkValid] = useState<boolean | null>(null);

  useEffect(() => {
    const hash = window.location.hash;
    if (hash.includes("type=recovery")) {
      setLinkValid(true);
      return;
    }
    supabase.auth.getSession().then(({ data }) => setLinkValid(Boolean(data.session)));
  }, []);

  async function submit() {
    if (password.length < 8) {
      toast.error("Use at least 8 characters.");
      return;
    }
    if (password !== confirm) {
      toast.error("The two passwords don't match.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password updated.");
    navigate({ to: "/dashboard", replace: true });
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-5 py-16">
      <Card className="w-full max-w-md border-border/70">
        <CardHeader>
          <CardTitle>Set a new password</CardTitle>
          <CardDescription>
            {linkValid === false
              ? "This reset link is no longer valid. Request a fresh one from the sign-in screen."
              : "Choose something you haven't used on this portal before."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {linkValid === false ? (
            <Button className="w-full" onClick={() => navigate({ to: "/auth" })}>
              Back to sign in
            </Button>
          ) : (
            <>
              <div className="space-y-2">
                <Label htmlFor="new-password">New password</Label>
                <Input
                  id="new-password"
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Repeat password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  autoComplete="new-password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={submit} disabled={busy}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : "Update password"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
