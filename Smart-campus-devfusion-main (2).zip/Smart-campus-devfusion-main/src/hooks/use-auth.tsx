import { useQueryClient } from "@tanstack/react-query";
import type { Session, User } from "@supabase/supabase-js";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

import { supabase } from "@/integrations/supabase/client";
import { primaryRole, type Role } from "@/lib/roles";

export type Profile = {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  roll_number: string | null;
  department_id: string | null;
  semester: number | null;
  skills: string[];
  linkedin_url: string | null;
  github_url: string | null;
  resume_url: string | null;
  avatar_url: string | null;
  bio: string | null;
  cgpa: number | null;
};

type AuthValue = {
  ready: boolean;
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  roles: Role[];
  role: Role;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthValue>({
  ready: false,
  session: null,
  user: null,
  profile: null,
  roles: [],
  role: "student",
  refreshProfile: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [ready, setReady] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    let active = true;

    async function hydrate(next: Session | null) {
      if (!next?.user) {
        if (!active) return;
        setProfile(null);
        setRoles([]);
        setReady(true);
        return;
      }
      const [profileResult, roleResult] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", next.user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", next.user.id),
      ]);
      if (!active) return;
      setProfile((profileResult.data as Profile | null) ?? null);
      setRoles((roleResult.data ?? []).map((r) => r.role as Role));
      setReady(true);
    }

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      void hydrate(data.session);
    });

    const { data: subscription } = supabase.auth.onAuthStateChange((event, next) => {
      setSession(next);
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
        void hydrate(next);
        if (event === "SIGNED_OUT") queryClient.clear();
      }
    });

    return () => {
      active = false;
      subscription.subscription.unsubscribe();
    };
  }, [queryClient]);

  const value = useMemo<AuthValue>(
    () => ({
      ready,
      session,
      user: session?.user ?? null,
      profile,
      roles,
      role: primaryRole(roles),
      refreshProfile: async () => {
        if (!session?.user) return;
        const { data } = await supabase.from("profiles").select("*").eq("id", session.user.id).maybeSingle();
        setProfile((data as Profile | null) ?? null);
      },
    }),
    [profile, ready, roles, session],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
